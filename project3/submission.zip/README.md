Project 3: ILP
Michael Goodnow, Zackary Mackay

With CPLEX we were able to get blazing fast solving of these problems
without much effort at all. ILP surpassed the exhaustive algorithm in 
speed and surpassed the greedy algorithm in optimality of solutions. 
In almost all cases it was able to find the optimal solution in under
10 minutes, except for a few very large graph coloring instances.
Given that we did not even have to write the algorithm this is very
impressive.
